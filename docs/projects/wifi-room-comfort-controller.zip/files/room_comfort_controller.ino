/*
 Learn With Rich: Wi-Fi Room Comfort Controller
 Arduino UNO R4 WiFi + DHT22 + I2C LCD + 5V relays.
 Only small 5V DC fan/lamp. No household mains wiring.
 Libraries: DHT sensor library by Adafruit, Adafruit Unified Sensor,
 LiquidCrystal_I2C. Board package: Arduino UNO R4 Boards.
*/
#include <WiFiS3.h>
#include <DHT.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
const char WIFI_NAME[] = "YOUR_WIFI_NAME";
const char WIFI_PASSWORD[] = "YOUR_WIFI_PASSWORD";
const byte DHT_PIN=2, FAN_RELAY_PIN=5, LAMP_RELAY_PIN=6;
const bool RELAY_ACTIVE_LOW=true; // set false only if your board is active-high
const float FAN_ON_C=30.0, FAN_OFF_C=28.0;
#define DHT_TYPE DHT22
DHT dht(DHT_PIN,DHT_TYPE);
LiquidCrystal_I2C lcd(0x27,16,2); // try 0x3F if your backpack uses that address
WiFiServer server(80);
bool fanOn=false, lampOn=false;
unsigned long lastRead=0;
float temperatureC=NAN, humidity=NAN;
void setRelay(byte pin,bool on){digitalWrite(pin,(on==RELAY_ACTIVE_LOW)?LOW:HIGH);}
void readSensor(){
 humidity=dht.readHumidity(); temperatureC=dht.readTemperature();
 if(!isnan(temperatureC)&&!isnan(humidity)){
  if(temperatureC>=FAN_ON_C)fanOn=true;
  if(temperatureC<=FAN_OFF_C)fanOn=false;
  setRelay(FAN_RELAY_PIN,fanOn);
 }
}
String statusPage(){
 String t=isnan(temperatureC)?"Waiting for sensor":String(temperatureC,1)+" &deg;C";
 String h=isnan(humidity)?"--":String(humidity,0)+" %";
 String p="<!doctype html><html><head><meta name='viewport' content='width=device-width'>";
 p+="<title>Room comfort</title></head><body style='font:20px sans-serif;max-width:650px;margin:40px auto;padding:16px'>";
 p+="<h1>Learn With Rich · Room comfort</h1><p>Temperature: "+t+"</p><p>Humidity: "+h+"</p>";
 p+="<p>Fan (automatic): "+String(fanOn?"ON":"OFF")+"</p><p>Lamp: "+String(lampOn?"ON":"OFF")+"</p>";
 p+="<p><a href='/lamp/on'>Lamp on</a> · <a href='/lamp/off'>Lamp off</a></p>";
 p+="<p>Fan turns on above 30°C and off below 28°C.</p></body></html>"; return p;
}
void answer(WiFiClient &client,const String &request){
 if(request.startsWith("GET /lamp/on")){lampOn=true;setRelay(LAMP_RELAY_PIN,true);}
 if(request.startsWith("GET /lamp/off")){lampOn=false;setRelay(LAMP_RELAY_PIN,false);}
 String p=statusPage();
 client.print("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nConnection: close\r\nContent-Length: ");
 client.print(p.length()); client.print("\r\n\r\n"); client.print(p);
}
void setup(){
 pinMode(FAN_RELAY_PIN,OUTPUT);pinMode(LAMP_RELAY_PIN,OUTPUT);
 setRelay(FAN_RELAY_PIN,false);setRelay(LAMP_RELAY_PIN,false);dht.begin();
 lcd.init();lcd.backlight();lcd.setCursor(0,0);lcd.print("Room controller");
 lcd.setCursor(0,1);lcd.print("Starting Wi-Fi");
 WiFi.begin(WIFI_NAME,WIFI_PASSWORD);
 unsigned long start=millis();
 while(WiFi.status()!=WL_CONNECTED&&millis()-start<20000)delay(250);
 if(WiFi.status()==WL_CONNECTED){server.begin();lcd.clear();lcd.print("Open browser:");lcd.setCursor(0,1);lcd.print(WiFi.localIP());}
 else{lcd.clear();lcd.print("Wi-Fi not ready");}
}
void loop(){
 if(millis()-lastRead>=2500){
  lastRead=millis();readSensor();lcd.setCursor(0,0);
  if(isnan(temperatureC))lcd.print("Temp: --.- C    ");
  else{lcd.print("Temp: ");lcd.print(temperatureC,1);lcd.print(" C     ");}
  lcd.setCursor(0,1);
  if(isnan(humidity))lcd.print("Humidity: -- %  ");
  else{lcd.print("Humidity: ");lcd.print(humidity,0);lcd.print(" %   ");}
 }
 WiFiClient client=server.available();
 if(client){String request=client.readStringUntil('\n');request.trim();answer(client,request);delay(1);client.stop();}
}
